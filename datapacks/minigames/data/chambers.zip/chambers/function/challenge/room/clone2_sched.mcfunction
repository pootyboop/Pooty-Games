say clone2 sched
execute at @e[type=area_effect_cloud,tag=clone2Queued] unless loaded ~-300 ~ ~ run return run schedule function chambers:challenge/room/clone2_sched 1
execute as @e[type=area_effect_cloud,tag=clone2Queued] at @s positioned ~-300 ~ ~ run function chambers:challenge/room/clone2